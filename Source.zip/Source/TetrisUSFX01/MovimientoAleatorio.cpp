



float DistanciaX;
float DistanciaY;
float DistanciaZ;

float TiempoTranscurrido;
float TiempoLimite;// Fill out your copyright notice in the Description page of Project Settings.


#include "MovimientoAleatorio.h"

// Add default functionality here for any IMovimientoAleatorio functions that are not pure virtual.
